from django.shortcuts import render

def Home(request):
    
    return render(request,"reg2.html")

# Create your views here.
